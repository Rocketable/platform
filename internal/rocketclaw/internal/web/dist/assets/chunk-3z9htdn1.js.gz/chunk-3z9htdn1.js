!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="C7F3A3F7A1F34F0264756E2164756E21")}catch(e){}}();
import{Y}from"./chunk-bf9zm3kt.js";export{Y as default};

//# debugId=C7F3A3F7A1F34F0264756E2164756E21
//# sourceMappingURL=chunk-3z9htdn1.js.map

//# chunkId=C7F3A3F7A1F34F0264756E2164756E21
