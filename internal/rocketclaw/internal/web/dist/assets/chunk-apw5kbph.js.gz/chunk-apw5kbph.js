!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="A715D6B247E5BE4464756E2164756E21")}catch(e){}}();
import{me}from"./chunk-hqan795d.js";export{me as default};

//# debugId=A715D6B247E5BE4464756E2164756E21
//# sourceMappingURL=chunk-apw5kbph.js.map

//# chunkId=A715D6B247E5BE4464756E2164756E21
