import{on}from"./main-pty51fbb.js";export{on as createJavaScriptRegexEngine};
