!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="1B38047F0540AD3F64756E2164756E21")}catch(e){}}();
import{Y}from"./chunk-bf9zm3kt.js";export{Y as default};

//# debugId=1B38047F0540AD3F64756E2164756E21
//# sourceMappingURL=chunk-7hg39v8k.js.map

//# chunkId=1B38047F0540AD3F64756E2164756E21
