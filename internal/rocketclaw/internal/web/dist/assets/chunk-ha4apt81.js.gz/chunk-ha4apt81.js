import{mn}from"./main-6dmtd4vv.js";export{mn as createJavaScriptRegexEngine};
