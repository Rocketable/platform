import{mn}from"./main-w7hsb58r.js";export{mn as createJavaScriptRegexEngine};
