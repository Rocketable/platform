import{tn}from"./chunk-5bpxktcp.js";export{tn as default};
