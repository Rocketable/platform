import{on}from"./main-2ghp70s5.js";export{on as createJavaScriptRegexEngine};
