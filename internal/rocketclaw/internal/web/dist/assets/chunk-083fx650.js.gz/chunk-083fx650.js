import{on}from"./main-e3ysycmc.js";export{on as createJavaScriptRegexEngine};
