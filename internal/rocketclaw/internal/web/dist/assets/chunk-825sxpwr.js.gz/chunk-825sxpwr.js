!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="735E1AD9A284D7DF64756E2164756E21")}catch(e){}}();
import{dt}from"./chunk-kmbasy6t.js";export{dt as default};

//# debugId=735E1AD9A284D7DF64756E2164756E21
//# sourceMappingURL=chunk-825sxpwr.js.map

//# chunkId=735E1AD9A284D7DF64756E2164756E21
