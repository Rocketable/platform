import{on}from"./main-1an4wnyg.js";export{on as createJavaScriptRegexEngine};
