!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="668846D957B744BD64756E2164756E21")}catch(e){}}();
import{Jt}from"./chunk-e5mjd34s.js";export{Jt as default};

//# debugId=668846D957B744BD64756E2164756E21
//# sourceMappingURL=chunk-pnxc67nz.js.map

//# chunkId=668846D957B744BD64756E2164756E21
