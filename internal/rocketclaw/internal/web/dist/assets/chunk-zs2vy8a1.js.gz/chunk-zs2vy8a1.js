import{mn}from"./main-jh18em9n.js";export{mn as createJavaScriptRegexEngine};
