import{on}from"./main-d4smmpx0.js";export{on as createJavaScriptRegexEngine};
