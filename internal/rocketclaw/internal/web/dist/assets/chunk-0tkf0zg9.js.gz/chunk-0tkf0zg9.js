!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="7786F1BCE2DCBFA164756E2164756E21")}catch(e){}}();
import{_}from"./chunk-h96nxass.js";export{_ as default};

//# debugId=7786F1BCE2DCBFA164756E2164756E21
//# sourceMappingURL=chunk-0tkf0zg9.js.map

//# chunkId=7786F1BCE2DCBFA164756E2164756E21
