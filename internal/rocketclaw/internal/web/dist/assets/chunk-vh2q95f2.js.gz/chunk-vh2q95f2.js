import{mn}from"./main-eqabg2j7.js";export{mn as createJavaScriptRegexEngine};
