import{on}from"./main-9k3gvy4d.js";export{on as createJavaScriptRegexEngine};
