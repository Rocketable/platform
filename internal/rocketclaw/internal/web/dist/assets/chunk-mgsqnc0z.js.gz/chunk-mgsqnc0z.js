import{on}from"./main-2q92cda6.js";export{on as createJavaScriptRegexEngine};
