import{on}from"./main-t5xda36s.js";export{on as createJavaScriptRegexEngine};
