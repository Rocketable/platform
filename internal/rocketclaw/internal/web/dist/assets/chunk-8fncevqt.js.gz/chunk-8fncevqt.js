import{on}from"./main-trwxsprt.js";export{on as createJavaScriptRegexEngine};
