import{on}from"./main-61wn32j4.js";export{on as createJavaScriptRegexEngine};
