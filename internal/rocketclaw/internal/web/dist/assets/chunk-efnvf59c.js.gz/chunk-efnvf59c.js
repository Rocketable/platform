!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="86BE0460A9060B5F64756E2164756E21")}catch(e){}}();
import{Rt}from"./chunk-h6q4cgcq.js";export{Rt as default};

//# debugId=86BE0460A9060B5F64756E2164756E21
//# sourceMappingURL=chunk-efnvf59c.js.map

//# chunkId=86BE0460A9060B5F64756E2164756E21
