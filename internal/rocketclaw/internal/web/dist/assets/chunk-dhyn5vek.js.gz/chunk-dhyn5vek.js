import{on}from"./main-v21kwt7d.js";export{on as createJavaScriptRegexEngine};
