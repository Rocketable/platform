import{mn}from"./main-7r1r4zqa.js";export{mn as createJavaScriptRegexEngine};
