import{on}from"./main-9pchzp4h.js";export{on as createJavaScriptRegexEngine};
