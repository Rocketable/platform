import{mn}from"./main-2tfbxb6e.js";export{mn as createJavaScriptRegexEngine};
