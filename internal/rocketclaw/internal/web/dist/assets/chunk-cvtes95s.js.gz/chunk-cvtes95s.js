import{mn}from"./main-jr7j5kpt.js";export{mn as createJavaScriptRegexEngine};
