import{on}from"./main-3tpw8y7m.js";export{on as createJavaScriptRegexEngine};
