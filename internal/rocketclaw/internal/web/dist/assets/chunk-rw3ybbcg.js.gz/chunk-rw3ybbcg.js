import{mn}from"./main-9pt1jf00.js";export{mn as createJavaScriptRegexEngine};
