import{C}from"./chunk-f3vfpptq.js";export{C as default};
