!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="1DBEC0635EEA889F64756E2164756E21")}catch(e){}}();
import{C}from"./chunk-f3vfpptq.js";export{C as default};

//# debugId=1DBEC0635EEA889F64756E2164756E21
//# sourceMappingURL=chunk-e1f3d81c.js.map

//# chunkId=1DBEC0635EEA889F64756E2164756E21
