!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="995F2CDA1864D62A64756E2164756E21")}catch(e){}}();
import{Ve}from"./chunk-50ayj5gq.js";export{Ve as default};

//# debugId=995F2CDA1864D62A64756E2164756E21
//# sourceMappingURL=chunk-tmqe9vhb.js.map

//# chunkId=995F2CDA1864D62A64756E2164756E21
