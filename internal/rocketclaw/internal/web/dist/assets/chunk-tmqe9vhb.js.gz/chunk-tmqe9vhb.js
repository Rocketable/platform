import{Ve}from"./chunk-50ayj5gq.js";export{Ve as default};
