import{mn}from"./main-1r0yyyvv.js";export{mn as createJavaScriptRegexEngine};
