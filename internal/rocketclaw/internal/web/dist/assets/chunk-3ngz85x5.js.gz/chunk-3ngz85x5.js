!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="024CFEEE917780E764756E2164756E21")}catch(e){}}();
import{We}from"./chunk-syrx38dg.js";export{We as default};

//# debugId=024CFEEE917780E764756E2164756E21
//# sourceMappingURL=chunk-3ngz85x5.js.map

//# chunkId=024CFEEE917780E764756E2164756E21
