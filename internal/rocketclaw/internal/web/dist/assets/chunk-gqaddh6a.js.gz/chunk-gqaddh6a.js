!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="880469F07BDB41B664756E2164756E21")}catch(e){}}();
import{kn}from"./chunk-0vscsnp7.js";export{kn as default};

//# debugId=880469F07BDB41B664756E2164756E21
//# sourceMappingURL=chunk-gqaddh6a.js.map

//# chunkId=880469F07BDB41B664756E2164756E21
