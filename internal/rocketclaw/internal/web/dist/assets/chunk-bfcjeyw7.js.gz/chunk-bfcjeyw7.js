import{on}from"./main-f8mw99gz.js";export{on as createJavaScriptRegexEngine};
