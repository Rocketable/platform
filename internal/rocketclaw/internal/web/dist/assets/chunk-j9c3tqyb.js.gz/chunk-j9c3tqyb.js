import{on}from"./main-pra266d1.js";export{on as createJavaScriptRegexEngine};
