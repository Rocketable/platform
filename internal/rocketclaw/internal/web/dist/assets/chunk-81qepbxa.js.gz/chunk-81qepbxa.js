import{mn}from"./main-t3az0nyg.js";export{mn as createJavaScriptRegexEngine};
