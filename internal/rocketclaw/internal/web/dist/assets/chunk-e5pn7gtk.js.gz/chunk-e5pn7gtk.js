import{mn}from"./main-hxh5cdbh.js";export{mn as createJavaScriptRegexEngine};
