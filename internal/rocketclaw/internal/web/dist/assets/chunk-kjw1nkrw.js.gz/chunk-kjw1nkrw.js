import{on}from"./main-3e2jdggj.js";export{on as createJavaScriptRegexEngine};
