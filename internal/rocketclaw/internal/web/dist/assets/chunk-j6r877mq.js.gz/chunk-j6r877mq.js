import{on}from"./main-sz26wq6v.js";export{on as createJavaScriptRegexEngine};
