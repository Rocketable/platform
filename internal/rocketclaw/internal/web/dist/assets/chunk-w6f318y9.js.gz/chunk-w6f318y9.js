import{mn}from"./main-bczwakhs.js";export{mn as createJavaScriptRegexEngine};
