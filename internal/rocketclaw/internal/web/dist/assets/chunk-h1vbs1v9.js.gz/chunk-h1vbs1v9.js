import{mn}from"./main-scbcdec6.js";export{mn as createJavaScriptRegexEngine};
