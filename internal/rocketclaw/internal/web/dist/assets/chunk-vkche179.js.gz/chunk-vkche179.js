import{on}from"./main-yxew1mx0.js";export{on as createJavaScriptRegexEngine};
