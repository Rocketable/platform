import{mn}from"./main-2cna8xhp.js";export{mn as createJavaScriptRegexEngine};
