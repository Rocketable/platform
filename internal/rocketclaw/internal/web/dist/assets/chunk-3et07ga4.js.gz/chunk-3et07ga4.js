import{mn}from"./main-ytfma22v.js";export{mn as createJavaScriptRegexEngine};
