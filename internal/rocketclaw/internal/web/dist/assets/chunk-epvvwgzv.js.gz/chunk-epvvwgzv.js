import{on}from"./main-k89vwsas.js";export{on as createJavaScriptRegexEngine};
