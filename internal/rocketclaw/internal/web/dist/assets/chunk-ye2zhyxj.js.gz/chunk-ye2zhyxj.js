import{mn}from"./main-a2j9m9sv.js";export{mn as createJavaScriptRegexEngine};
