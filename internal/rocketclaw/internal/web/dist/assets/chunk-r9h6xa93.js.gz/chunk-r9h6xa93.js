import{mn}from"./main-my9sabng.js";export{mn as createJavaScriptRegexEngine};
