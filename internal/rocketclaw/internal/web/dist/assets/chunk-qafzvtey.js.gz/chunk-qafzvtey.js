!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="556EC1C59EEF334764756E2164756E21")}catch(e){}}();
import{dt}from"./chunk-kmbasy6t.js";export{dt as default};

//# debugId=556EC1C59EEF334764756E2164756E21
//# sourceMappingURL=chunk-qafzvtey.js.map

//# chunkId=556EC1C59EEF334764756E2164756E21
