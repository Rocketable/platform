import{mn}from"./main-7sz6g05h.js";export{mn as createJavaScriptRegexEngine};
