!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="DDFDE381C71915F764756E2164756E21")}catch(e){}}();
import{P}from"./chunk-98y89t7c.js";import"./chunk-k0tmxv9c.js";import"./chunk-zwfnwyjc.js";import"./chunk-v5a56nhb.js";export{P as default};

//# debugId=DDFDE381C71915F764756E2164756E21
//# sourceMappingURL=chunk-470yxqn5.js.map

//# chunkId=DDFDE381C71915F764756E2164756E21
