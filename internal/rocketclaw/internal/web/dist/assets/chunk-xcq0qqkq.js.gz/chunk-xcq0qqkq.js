!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="15B5B649889293E564756E2164756E21")}catch(e){}}();
import{Ze}from"./chunk-zx9g5f4x.js";export{Ze as default};

//# debugId=15B5B649889293E564756E2164756E21
//# sourceMappingURL=chunk-xcq0qqkq.js.map

//# chunkId=15B5B649889293E564756E2164756E21
