import{mn}from"./main-eaj2a6fh.js";export{mn as createJavaScriptRegexEngine};
