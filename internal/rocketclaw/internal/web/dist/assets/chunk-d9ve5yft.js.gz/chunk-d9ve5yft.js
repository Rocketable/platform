!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="6D943FE5B622862364756E2164756E21")}catch(e){}}();
import{wn}from"./chunk-ww514pej.js";export{wn as default};

//# debugId=6D943FE5B622862364756E2164756E21
//# sourceMappingURL=chunk-d9ve5yft.js.map

//# chunkId=6D943FE5B622862364756E2164756E21
