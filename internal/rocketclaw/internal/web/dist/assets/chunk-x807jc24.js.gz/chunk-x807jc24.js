import{mn}from"./main-cf0kdce6.js";export{mn as createJavaScriptRegexEngine};
