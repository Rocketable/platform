import{on}from"./main-7n7ehfqs.js";export{on as createJavaScriptRegexEngine};
