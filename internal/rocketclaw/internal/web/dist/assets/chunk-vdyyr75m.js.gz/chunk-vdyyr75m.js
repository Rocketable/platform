import{on}from"./main-j9q2qtyd.js";export{on as createJavaScriptRegexEngine};
