import{mn}from"./main-7ps7fth8.js";export{mn as createJavaScriptRegexEngine};
