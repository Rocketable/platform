!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="D56A0AA706BFCADF64756E2164756E21")}catch(e){}}();
import{ie}from"./chunk-y46et5ck.js";export{ie as default};

//# debugId=D56A0AA706BFCADF64756E2164756E21
//# sourceMappingURL=chunk-01pdqpn8.js.map

//# chunkId=D56A0AA706BFCADF64756E2164756E21
