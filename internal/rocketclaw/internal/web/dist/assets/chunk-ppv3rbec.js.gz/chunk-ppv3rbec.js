import{mn}from"./main-zsa3x0v5.js";export{mn as createJavaScriptRegexEngine};
