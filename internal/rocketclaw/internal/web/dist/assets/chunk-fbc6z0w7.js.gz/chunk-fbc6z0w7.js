import{mn}from"./main-f74c761h.js";export{mn as createJavaScriptRegexEngine};
