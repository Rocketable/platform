!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="5CE51A09337B848964756E2164756E21")}catch(e){}}();
import{Xt}from"./chunk-dm0xyrt9.js";export{Xt as default};

//# debugId=5CE51A09337B848964756E2164756E21
//# sourceMappingURL=chunk-c63x7a0y.js.map

//# chunkId=5CE51A09337B848964756E2164756E21
