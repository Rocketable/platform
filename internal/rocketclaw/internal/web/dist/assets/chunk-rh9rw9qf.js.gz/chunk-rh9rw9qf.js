import{mn}from"./main-3egz5q4d.js";export{mn as createJavaScriptRegexEngine};
