import{mn}from"./main-wjsj1316.js";export{mn as createJavaScriptRegexEngine};
