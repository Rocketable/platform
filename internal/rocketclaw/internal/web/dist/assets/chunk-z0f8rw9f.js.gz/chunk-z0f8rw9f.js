import{mn}from"./main-r5psx971.js";export{mn as createJavaScriptRegexEngine};
