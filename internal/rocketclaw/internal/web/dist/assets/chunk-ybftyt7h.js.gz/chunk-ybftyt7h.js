!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="E2D5253A32CFCAA664756E2164756E21")}catch(e){}}();
import{en}from"./chunk-h6emg1y7.js";export{en as default};

//# debugId=E2D5253A32CFCAA664756E2164756E21
//# sourceMappingURL=chunk-ybftyt7h.js.map

//# chunkId=E2D5253A32CFCAA664756E2164756E21
