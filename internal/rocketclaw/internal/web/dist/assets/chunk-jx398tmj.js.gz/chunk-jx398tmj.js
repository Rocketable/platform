import{on}from"./main-zz57gwws.js";export{on as createJavaScriptRegexEngine};
