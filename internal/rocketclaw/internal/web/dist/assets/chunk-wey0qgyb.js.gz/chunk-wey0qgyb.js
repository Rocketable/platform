import{mn}from"./main-t3fps0d2.js";export{mn as createJavaScriptRegexEngine};
