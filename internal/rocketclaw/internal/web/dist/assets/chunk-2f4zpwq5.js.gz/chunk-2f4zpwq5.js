import{on}from"./main-4d045apr.js";export{on as createJavaScriptRegexEngine};
