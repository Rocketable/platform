!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="9A946DEAA7326A4F64756E2164756E21")}catch(e){}}();
import{Dt}from"./chunk-j49bb4bf.js";export{Dt as default};

//# debugId=9A946DEAA7326A4F64756E2164756E21
//# sourceMappingURL=chunk-fma7gnvv.js.map

//# chunkId=9A946DEAA7326A4F64756E2164756E21
