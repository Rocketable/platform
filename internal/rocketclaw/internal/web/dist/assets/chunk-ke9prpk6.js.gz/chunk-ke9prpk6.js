import{on}from"./main-hp1pvzwh.js";export{on as createJavaScriptRegexEngine};
