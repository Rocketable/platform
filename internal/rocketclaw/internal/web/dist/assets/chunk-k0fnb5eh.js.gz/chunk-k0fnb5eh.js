!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="CBEB3AF0A8780EA264756E2164756E21")}catch(e){}}();
import{Vt}from"./chunk-ng8ws00b.js";import"./chunk-jtafq69h.js";export{Vt as default};

//# debugId=CBEB3AF0A8780EA264756E2164756E21
//# sourceMappingURL=chunk-k0fnb5eh.js.map

//# chunkId=CBEB3AF0A8780EA264756E2164756E21
