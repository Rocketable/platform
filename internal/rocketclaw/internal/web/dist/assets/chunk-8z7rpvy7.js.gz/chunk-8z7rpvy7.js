!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="0202632238314B8B64756E2164756E21")}catch(e){}}();
import{Tt}from"./chunk-pq4jq5rc.js";export{Tt as default};

//# debugId=0202632238314B8B64756E2164756E21
//# sourceMappingURL=chunk-8z7rpvy7.js.map

//# chunkId=0202632238314B8B64756E2164756E21
