!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="33252DAFC4EC17B564756E2164756E21")}catch(e){}}();
import{Ot}from"./chunk-9z7kp1dz.js";export{Ot as default};

//# debugId=33252DAFC4EC17B564756E2164756E21
//# sourceMappingURL=chunk-qa8sfpxf.js.map

//# chunkId=33252DAFC4EC17B564756E2164756E21
