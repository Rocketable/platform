!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="922F7574054A5E4264756E2164756E21")}catch(e){}}();
import{Te}from"./chunk-45d7qj6e.js";export{Te as default};

//# debugId=922F7574054A5E4264756E2164756E21
//# sourceMappingURL=chunk-3wahgw6v.js.map

//# chunkId=922F7574054A5E4264756E2164756E21
