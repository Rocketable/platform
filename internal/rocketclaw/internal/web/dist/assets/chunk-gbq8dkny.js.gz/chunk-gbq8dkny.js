!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="5A47363916DD82AC64756E2164756E21")}catch(e){}}();
import{ie}from"./chunk-y46et5ck.js";export{ie as default};

//# debugId=5A47363916DD82AC64756E2164756E21
//# sourceMappingURL=chunk-gbq8dkny.js.map

//# chunkId=5A47363916DD82AC64756E2164756E21
