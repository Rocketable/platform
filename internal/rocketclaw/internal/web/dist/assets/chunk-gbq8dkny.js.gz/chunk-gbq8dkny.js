import{ie}from"./chunk-y46et5ck.js";export{ie as default};
