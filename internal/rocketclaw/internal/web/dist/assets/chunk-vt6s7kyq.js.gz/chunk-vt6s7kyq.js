import{mn}from"./main-q9brb24c.js";export{mn as createJavaScriptRegexEngine};
