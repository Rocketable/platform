!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="D0C10AA862FF42AE64756E2164756E21")}catch(e){}}();
import{B}from"./chunk-kw15k53t.js";export{B as default};

//# debugId=D0C10AA862FF42AE64756E2164756E21
//# sourceMappingURL=chunk-j1bfwt8s.js.map

//# chunkId=D0C10AA862FF42AE64756E2164756E21
