!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="5B0D22B5509E589664756E2164756E21")}catch(e){}}();
import{X}from"./chunk-wr5na6q6.js";export{X as default};

//# debugId=5B0D22B5509E589664756E2164756E21
//# sourceMappingURL=chunk-r1f0d01m.js.map

//# chunkId=5B0D22B5509E589664756E2164756E21
