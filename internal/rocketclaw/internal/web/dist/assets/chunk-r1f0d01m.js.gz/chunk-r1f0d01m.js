import{X}from"./chunk-wr5na6q6.js";export{X as default};
