!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="64244C77486731CB64756E2164756E21")}catch(e){}}();
import{$e}from"./chunk-he9mz4ya.js";export{$e as default};

//# debugId=64244C77486731CB64756E2164756E21
//# sourceMappingURL=chunk-vdas9c9m.js.map

//# chunkId=64244C77486731CB64756E2164756E21
