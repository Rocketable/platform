import{on}from"./main-03d9eajc.js";export{on as createJavaScriptRegexEngine};
