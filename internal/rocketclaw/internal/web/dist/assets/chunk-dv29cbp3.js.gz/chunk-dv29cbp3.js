import{on}from"./main-nxvn1rsy.js";export{on as createJavaScriptRegexEngine};
