!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="82586CB6D8F0BC1364756E2164756E21")}catch(e){}}();
import{C}from"./chunk-f3vfpptq.js";export{C as default};

//# debugId=82586CB6D8F0BC1364756E2164756E21
//# sourceMappingURL=chunk-fvrm5w5t.js.map

//# chunkId=82586CB6D8F0BC1364756E2164756E21
