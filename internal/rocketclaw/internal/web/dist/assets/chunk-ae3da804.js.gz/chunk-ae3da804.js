import{on}from"./main-kej2gqq4.js";export{on as createJavaScriptRegexEngine};
