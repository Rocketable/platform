import{mn}from"./main-pf5xnpz5.js";export{mn as createJavaScriptRegexEngine};
