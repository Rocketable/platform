import{en}from"./chunk-tbrgnyca.js";export{en as default};
