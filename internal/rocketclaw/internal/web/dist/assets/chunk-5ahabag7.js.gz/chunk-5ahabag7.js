import{mn}from"./main-1bzfmzd9.js";export{mn as createJavaScriptRegexEngine};
