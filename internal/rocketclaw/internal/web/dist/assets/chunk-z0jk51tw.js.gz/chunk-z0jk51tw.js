import{mn}from"./main-qg9f30dc.js";export{mn as createJavaScriptRegexEngine};
