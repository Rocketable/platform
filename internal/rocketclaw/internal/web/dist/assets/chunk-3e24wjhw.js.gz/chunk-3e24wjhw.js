import{mn}from"./main-ppr71t45.js";export{mn as createJavaScriptRegexEngine};
