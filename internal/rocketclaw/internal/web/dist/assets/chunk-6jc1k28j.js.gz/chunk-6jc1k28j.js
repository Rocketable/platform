import{mn}from"./main-dkdgf0m2.js";export{mn as createJavaScriptRegexEngine};
