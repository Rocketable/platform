!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="AB75E4516C48351764756E2164756E21")}catch(e){}}();
import{Yt}from"./chunk-hjakbc5q.js";export{Yt as default};

//# debugId=AB75E4516C48351764756E2164756E21
//# sourceMappingURL=chunk-4sn10ckd.js.map

//# chunkId=AB75E4516C48351764756E2164756E21
