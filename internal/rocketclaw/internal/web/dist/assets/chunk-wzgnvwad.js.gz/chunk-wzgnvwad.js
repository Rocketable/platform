import{on}from"./main-wz7f8yxy.js";export{on as createJavaScriptRegexEngine};
