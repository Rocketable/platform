import{on}from"./main-6avsb3fh.js";export{on as createJavaScriptRegexEngine};
