import{mn}from"./main-fxt515gq.js";export{mn as createJavaScriptRegexEngine};
