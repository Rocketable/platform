import{on}from"./main-mwk9pmw5.js";export{on as createJavaScriptRegexEngine};
