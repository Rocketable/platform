import{mn}from"./main-p6mtb7yd.js";export{mn as createJavaScriptRegexEngine};
