!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="F96619A77C7CCE0C64756E2164756E21")}catch(e){}}();
import{V}from"./chunk-zwfnwyjc.js";import"./chunk-v5a56nhb.js";export{V as default};

//# debugId=F96619A77C7CCE0C64756E2164756E21
//# sourceMappingURL=chunk-2chp8mjx.js.map

//# chunkId=F96619A77C7CCE0C64756E2164756E21
