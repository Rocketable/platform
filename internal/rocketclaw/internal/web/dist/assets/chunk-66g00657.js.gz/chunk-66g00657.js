!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="4F3ED89B543C211664756E2164756E21")}catch(e){}}();
import{Wt}from"./chunk-2geqrrnr.js";export{Wt as default};

//# debugId=4F3ED89B543C211664756E2164756E21
//# sourceMappingURL=chunk-66g00657.js.map

//# chunkId=4F3ED89B543C211664756E2164756E21
