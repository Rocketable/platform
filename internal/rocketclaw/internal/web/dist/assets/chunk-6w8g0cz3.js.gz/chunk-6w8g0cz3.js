import{on}from"./main-5m287mbw.js";export{on as createJavaScriptRegexEngine};
