import{on}from"./main-t1b2p51p.js";export{on as createJavaScriptRegexEngine};
