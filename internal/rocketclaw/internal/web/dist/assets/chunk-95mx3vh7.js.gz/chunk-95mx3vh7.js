!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="31F8D6A437DA3E5F64756E2164756E21")}catch(e){}}();
import{_}from"./chunk-h96nxass.js";export{_ as default};

//# debugId=31F8D6A437DA3E5F64756E2164756E21
//# sourceMappingURL=chunk-95mx3vh7.js.map

//# chunkId=31F8D6A437DA3E5F64756E2164756E21
