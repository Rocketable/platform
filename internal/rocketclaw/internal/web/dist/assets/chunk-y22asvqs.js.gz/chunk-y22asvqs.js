import{mn}from"./main-4wn630gp.js";export{mn as createJavaScriptRegexEngine};
