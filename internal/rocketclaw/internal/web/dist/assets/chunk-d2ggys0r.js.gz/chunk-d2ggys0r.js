import{on}from"./main-w959qmcb.js";export{on as createJavaScriptRegexEngine};
