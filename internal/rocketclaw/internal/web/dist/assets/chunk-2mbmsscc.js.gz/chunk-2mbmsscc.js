import{B}from"./chunk-kw15k53t.js";export{B as default};
