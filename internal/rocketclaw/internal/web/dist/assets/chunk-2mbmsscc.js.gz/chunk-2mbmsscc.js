!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="34F861D3ACE5516D64756E2164756E21")}catch(e){}}();
import{B}from"./chunk-kw15k53t.js";export{B as default};

//# debugId=34F861D3ACE5516D64756E2164756E21
//# sourceMappingURL=chunk-2mbmsscc.js.map

//# chunkId=34F861D3ACE5516D64756E2164756E21
