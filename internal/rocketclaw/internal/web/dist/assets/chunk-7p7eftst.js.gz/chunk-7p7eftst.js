!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="4FC330B7995C587164756E2164756E21")}catch(e){}}();
import{Ft}from"./chunk-tdw52p3d.js";export{Ft as default};

//# debugId=4FC330B7995C587164756E2164756E21
//# sourceMappingURL=chunk-7p7eftst.js.map

//# chunkId=4FC330B7995C587164756E2164756E21
