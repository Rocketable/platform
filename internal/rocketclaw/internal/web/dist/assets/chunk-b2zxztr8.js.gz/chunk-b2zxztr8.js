!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="A4E6330AF9B7135464756E2164756E21")}catch(e){}}();
import{oe}from"./chunk-d1a2hqy0.js";export{oe as default};

//# debugId=A4E6330AF9B7135464756E2164756E21
//# sourceMappingURL=chunk-b2zxztr8.js.map

//# chunkId=A4E6330AF9B7135464756E2164756E21
