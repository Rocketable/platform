import{mn}from"./main-f5s0jzg6.js";export{mn as createJavaScriptRegexEngine};
