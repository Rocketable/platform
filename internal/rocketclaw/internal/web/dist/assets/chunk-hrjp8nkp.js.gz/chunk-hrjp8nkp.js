import{on}from"./main-3g8wbbhq.js";export{on as createJavaScriptRegexEngine};
