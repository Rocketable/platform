import{mn}from"./main-m2b6c8eh.js";export{mn as createJavaScriptRegexEngine};
