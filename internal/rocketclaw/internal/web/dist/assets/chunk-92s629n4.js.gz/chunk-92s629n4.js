import{mn}from"./main-t2m6r2fs.js";export{mn as createJavaScriptRegexEngine};
