import{mn}from"./main-3shvyz1p.js";export{mn as createJavaScriptRegexEngine};
