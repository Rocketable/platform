import{E}from"./chunk-v5a56nhb.js";export{E as default};
