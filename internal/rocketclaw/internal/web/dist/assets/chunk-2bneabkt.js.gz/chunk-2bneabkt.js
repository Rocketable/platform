!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="FD566592D6F9E20664756E2164756E21")}catch(e){}}();
import{E}from"./chunk-v5a56nhb.js";export{E as default};

//# debugId=FD566592D6F9E20664756E2164756E21
//# sourceMappingURL=chunk-2bneabkt.js.map

//# chunkId=FD566592D6F9E20664756E2164756E21
