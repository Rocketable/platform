import{mn}from"./main-bd26hwv3.js";export{mn as createJavaScriptRegexEngine};
