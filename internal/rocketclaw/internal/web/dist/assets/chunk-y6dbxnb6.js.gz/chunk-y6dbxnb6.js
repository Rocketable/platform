import{on}from"./main-wh88axdy.js";export{on as createJavaScriptRegexEngine};
