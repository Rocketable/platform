import{mn}from"./main-0066p7za.js";export{mn as createJavaScriptRegexEngine};
