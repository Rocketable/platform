import{mn}from"./main-bxrg9c31.js";export{mn as createJavaScriptRegexEngine};
