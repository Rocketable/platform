import{mn}from"./main-f5znmwnd.js";export{mn as createJavaScriptRegexEngine};
