!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="8874A875096DFCBF64756E2164756E21")}catch(e){}}();
import{De}from"./chunk-wwv8q9qa.js";export{De as default};

//# debugId=8874A875096DFCBF64756E2164756E21
//# sourceMappingURL=chunk-78a2ne2e.js.map

//# chunkId=8874A875096DFCBF64756E2164756E21
