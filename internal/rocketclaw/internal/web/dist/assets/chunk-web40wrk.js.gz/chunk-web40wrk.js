!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="1E1C3F60429C2D6B64756E2164756E21")}catch(e){}}();
import{gn}from"./main-g6xmm913.js";export{gn as createJavaScriptRegexEngine};

//# debugId=1E1C3F60429C2D6B64756E2164756E21
//# sourceMappingURL=chunk-web40wrk.js.map

//# chunkId=1E1C3F60429C2D6B64756E2164756E21
