!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="1F760EDFD976B10264756E2164756E21")}catch(e){}}();
import{Me}from"./chunk-34q0g4vb.js";export{Me as default};

//# debugId=1F760EDFD976B10264756E2164756E21
//# sourceMappingURL=chunk-cqatn6wq.js.map

//# chunkId=1F760EDFD976B10264756E2164756E21
