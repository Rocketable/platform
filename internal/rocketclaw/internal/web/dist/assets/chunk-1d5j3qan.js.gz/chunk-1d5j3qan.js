import{mn}from"./main-x8w06mhj.js";export{mn as createJavaScriptRegexEngine};
