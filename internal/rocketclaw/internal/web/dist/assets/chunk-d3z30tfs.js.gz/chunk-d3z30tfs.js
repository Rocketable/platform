import{mn}from"./main-k1rm0bbm.js";export{mn as createJavaScriptRegexEngine};
