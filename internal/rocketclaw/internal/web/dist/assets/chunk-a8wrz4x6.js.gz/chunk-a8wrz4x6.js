import{on}from"./main-p62x5h25.js";export{on as createJavaScriptRegexEngine};
