import{mn}from"./main-xn0chfje.js";export{mn as createJavaScriptRegexEngine};
