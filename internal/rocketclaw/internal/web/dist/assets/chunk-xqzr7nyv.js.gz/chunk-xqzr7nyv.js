import{mn}from"./main-1hm3jbt2.js";export{mn as createJavaScriptRegexEngine};
