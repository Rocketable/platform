!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="36DD3C04C8426DEF64756E2164756E21")}catch(e){}}();
import{wn}from"./chunk-ww514pej.js";export{wn as default};

//# debugId=36DD3C04C8426DEF64756E2164756E21
//# sourceMappingURL=chunk-q908xzev.js.map

//# chunkId=36DD3C04C8426DEF64756E2164756E21
