import{on}from"./main-dhxvtp4p.js";export{on as createJavaScriptRegexEngine};
