import{mn}from"./main-9wcyrpyb.js";export{mn as createJavaScriptRegexEngine};
