!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="05571396D4C3657C64756E2164756E21")}catch(e){}}();
import{D}from"./chunk-k0kbjzxv.js";import"./chunk-vx3t9zes.js";export{D as default};

//# debugId=05571396D4C3657C64756E2164756E21
//# sourceMappingURL=chunk-97bfzhq7.js.map

//# chunkId=05571396D4C3657C64756E2164756E21
