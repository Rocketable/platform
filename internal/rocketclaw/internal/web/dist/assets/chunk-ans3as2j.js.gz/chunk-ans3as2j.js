import{mn}from"./main-ggphgsb1.js";export{mn as createJavaScriptRegexEngine};
