!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="DAF0D65FA46AA43D64756E2164756E21")}catch(e){}}();
import{tn}from"./chunk-w5aq8788.js";export{tn as default};

//# debugId=DAF0D65FA46AA43D64756E2164756E21
//# sourceMappingURL=chunk-ex0ap2bv.js.map

//# chunkId=DAF0D65FA46AA43D64756E2164756E21
