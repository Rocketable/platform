import{mn}from"./main-9g41p6yv.js";export{mn as createJavaScriptRegexEngine};
