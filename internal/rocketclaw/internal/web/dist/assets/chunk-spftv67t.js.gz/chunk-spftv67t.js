import{mn}from"./main-mbp3hygh.js";export{mn as createJavaScriptRegexEngine};
