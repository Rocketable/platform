!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="5798B227985A004D64756E2164756E21")}catch(e){}}();
import{Ne}from"./chunk-fnz57ewv.js";export{Ne as default};

//# debugId=5798B227985A004D64756E2164756E21
//# sourceMappingURL=chunk-y13afj3h.js.map

//# chunkId=5798B227985A004D64756E2164756E21
