import{mn}from"./main-zmx3j1mn.js";export{mn as createJavaScriptRegexEngine};
