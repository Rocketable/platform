import{mn}from"./main-2q5etxvp.js";export{mn as createJavaScriptRegexEngine};
