!function(){try{var n=(new Error).stack;n&&((globalThis._posthogChunkIds=globalThis._posthogChunkIds||{})[n]="6CB69EE34EBAC01564756E2164756E21")}catch(e){}}();
import{kn}from"./chunk-0vscsnp7.js";export{kn as default};

//# debugId=6CB69EE34EBAC01564756E2164756E21
//# sourceMappingURL=chunk-s4j2qy6m.js.map

//# chunkId=6CB69EE34EBAC01564756E2164756E21
