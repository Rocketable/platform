import{mn}from"./main-g4t2w8f1.js";export{mn as createJavaScriptRegexEngine};
