import{mn}from"./main-rc2npn6t.js";export{mn as createJavaScriptRegexEngine};
